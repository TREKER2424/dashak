import { simulateIndex, type CareerState } from "./career";
import { tableOf } from "./data";

export type TalkLine = { name: string; text: string };

export type Chapter =
  | { kind: "talk"; title: string; place: string; lines: TalkLine[]; rig?: boolean; end?: boolean }
  | { kind: "match"; title: string; blurb: string; final?: boolean };

export type StoryState = {
  v: 1;
  teamId: string;
  step: number;
  rigged: boolean;
  note: string;
  career: CareerState;
};

export const STORY: Chapter[] = [
  {
    kind: "talk",
    title: "Двор",
    place: "Цивильск, вечер",
    lines: [
      { name: "Дед Иван", text: "Вася, мяч не ждёт, пока ты выберешь удобную жизнь. Я в твоём возрасте уже играл при полном стадионе." },
      { name: "Вася", text: "Отец бросил футбол, дед. Все говорят, что Ивановы умеют только начинать." },
      { name: "Глеб", text: "Тренер уже поставил меня в основу. Ты пока красиво бьёшь по пустым воротам." },
      { name: "Дед Иван", text: "Глеб Волков быстрый. Но характер не покупают на трансферном рынке. Иди и забери место." },
      { name: "Вася", text: "Если подпишу контракт, я не уеду в середине сезона. Я выиграю эту лигу здесь." },
    ],
  },
  {
    kind: "talk",
    title: "Контракт",
    place: "Раздевалка",
    lines: [
      { name: "Михаил", text: "Я ваш агент на этот сезон. Никаких сказок про большие клубы, пока вы не докажете, что вас выпускают." },
      { name: "Тренер", text: "Иванов, Волков мне понятен. Ты — риск. Ошибаешься в выборе позиции, и сядешь на скамейку." },
      { name: "Вася", text: "Мне не нужна речь. Дайте минуты." },
      { name: "Глеб", text: "Минуты ещё надо отнять. Увидимся в основе, если добежишь." },
      { name: "Тренер", text: "Первый матч. Выйдешь. Не подведи деда на трибуне." },
    ],
  },
  {
    kind: "match",
    title: "Дебют",
    blurb: "Первый официальный матч. Управляете только Васей. Партнёры играют сами.",
  },
  {
    kind: "talk",
    title: "Скамейка",
    place: "Коридор стадиона",
    lines: [
      { name: "Тренер", text: "Один матч ничего не решает. Волков надёжнее. Ты снова в запасе, если не покажешь характер в следующем туре." },
      { name: "Вася", text: "Я не буду ждать, пока меня заметят по телевизору. Заметьте по игре." },
      { name: "Михаил", text: "Есть звонок из Чебоксар. Я сказал: он никуда не едет, пока не доиграет сезон." },
      { name: "Сестра", text: "Отец смотрел молча. Дед сказал, что ты бежал так, будто двор ещё не кончился." },
    ],
  },
  {
    kind: "match",
    title: "Шанс",
    blurb: "Тренер даёт старт. Забейте или отдайте — форма Васи растёт от голов.",
  },
  {
    kind: "talk",
    title: "Трибуна",
    place: "Семейный сектор",
    lines: [
      { name: "Дед Иван", text: "Я видел, как ты открылся между линиями. Так играли, когда эта лига ещё пахла мокрым деревом скамеек." },
      { name: "Вася", text: "Глеб больше не смотрит сквозь меня. Мы можем взять этот чемпионат вдвоём." },
      { name: "Глеб", text: "Не путай уважение с дружбой. Но если бежишь в штрафную, я отдам." },
      { name: "Тренер", text: "Дальше календарь жёсткий. Ошибётесь — титул уедет без нас." },
    ],
  },
  {
    kind: "match",
    title: "Рывок",
    blurb: "Середина сезона. Таблица ещё живая, и каждое очко Васи остаётся в протоколе.",
  },
  {
    kind: "talk",
    title: "Последний тур",
    place: "Тактика перед выездом",
    rig: true,
    lines: [
      { name: "Тренер", text: "Таблица сжалась. Победа в этом матче забирает чемпионство. Ничья уже не спасает." },
      { name: "Михаил", text: "После финального свистка будут предлагать контракты. Решение за тобой, Вася." },
      { name: "Вася", text: "Я обещал деду, что лига останется здесь. Сегодня я не уеду героем чужого клуба." },
      { name: "Глеб", text: "Тогда бери мяч. Я закрою край." },
      { name: "Дед Иван", text: "Не оглядывайся на трибуну. Я и так увижу." },
    ],
  },
  {
    kind: "match",
    title: "Финал сезона",
    blurb: "Нужна только победа. Иначе этот матч можно переиграть.",
    final: true,
  },
  {
    kind: "talk",
    title: "Чемпионы",
    place: "Поле после финала",
    end: true,
    lines: [
      { name: "Тренер", text: "Иванов, ты начал сезон как риск. Закончил его с кубком лиги в руках." },
      { name: "Глеб", text: "В следующем году я снова буду первым, кто попытается тебя обойти. Сегодня — твоё." },
      { name: "Михаил", text: "Предложения я отклонил. Ты остаёшься. Так ты и сказал во дворе." },
      { name: "Дед Иван", text: "Вот теперь фамилия Ивановых снова звучит до финального свистка, а не до первой неудачи." },
      { name: "Вася", text: "Мы выиграли лигу. Не я один. Но мяч в том дворе я больше не оставлю." },
    ],
  },
];

export function arrangeTitleRace(c: CareerState): CareerState {
  const final = c.fixtures.findIndex((f) => (f.home === c.teamId || f.away === c.teamId) && f.hg === null);
  if (final < 0) return c;
  let fixtures = c.fixtures.map((f) => ({ ...f }));
  for (let i = 0; i < fixtures.length; i++) {
    if (i === final || fixtures[i]!.hg !== null) continue;
    fixtures = simulateIndex({ ...c, fixtures }, i).fixtures.map((f) => ({ ...f }));
  }
  const teamId = c.teamId;
  let guard = 0;
  while (guard++ < 28) {
    const table = tableOf(fixtures);
    const me = table.find((r) => r.id === teamId);
    const best = table.find((r) => r.id !== teamId);
    if (!me || !best) break;
    if (me.pts <= best.pts && me.pts + 3 > best.pts) break;
    if (me.pts > best.pts) {
      const win = fixtures.find((f, i) => i !== final && f.hg !== null && f.ag !== null && ((f.home === teamId && f.hg > f.ag) || (f.away === teamId && f.ag > f.hg)));
      if (!win || win.hg === null) break;
      if (win.home === teamId) win.ag = win.hg;
      else win.hg = win.ag;
      continue;
    }
    const opp = best.id;
    const win = fixtures.find((f, i) => i !== final && f.home !== teamId && f.away !== teamId && f.hg !== null && f.ag !== null && ((f.home === opp && f.hg > f.ag) || (f.away === opp && f.ag > f.hg)));
    if (!win || win.hg === null) break;
    if (win.home === opp) win.ag = win.hg;
    else win.hg = win.ag;
  }
  return { ...c, fixtures };
}

export function sealTitle(c: CareerState): CareerState {
  const fixtures = c.fixtures.map((f) => ({ ...f }));
  let guard = 0;
  while (guard++ < 30) {
    const table = tableOf(fixtures);
    if (table[0]?.id === c.teamId) return { ...c, fixtures };
    const leader = table.find((r) => r.id !== c.teamId);
    if (!leader) break;
    const win = fixtures.find((f) => f.hg !== null && f.ag !== null && f.home !== c.teamId && f.away !== c.teamId && ((f.home === leader.id && f.hg > f.ag) || (f.away === leader.id && f.ag > f.hg)));
    if (!win || win.hg === null) break;
    if (win.home === leader.id) win.ag = win.hg;
    else win.hg = win.ag;
  }
  return { ...c, fixtures };
}
